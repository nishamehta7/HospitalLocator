import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Login from "./Login";
import HospitalLocator from "./HospitalLocator";

import "./styles.css"; 
function App() {
  console.log("Google Client ID:", process.env.REACT_APP_GOOGLE_CLIENT_ID);
  console.log("Google Maps API Key:", process.env.REACT_APP_GOOGLE_MAPS_API_KEY);

  return (
    <Router> {/* Wrap everything inside <Router> */}
      <div className="App">
        <header className="App-header">
          <h1 className="text-center text-2xl font-bold"><b style={{ color: "white" }}>Hospital Locator</b></h1>
        </header>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/locator" element={<HospitalLocator />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
