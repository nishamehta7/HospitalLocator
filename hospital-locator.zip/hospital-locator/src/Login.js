import React from "react";
import { signInWithPopup } from "firebase/auth";
import { auth, provider } from "./firebaseConfig";
import { useNavigate } from "react-router-dom";
import "./styles.css";
export default function Login() {

  const navigate = useNavigate();
  const handleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, provider);
      console.log("User Logged In:", result.user);
      navigate("/locator");
    } catch (error) {
      console.error("Login Failed", error);
    }
  };
  return (
    <div className="flex flex-col items-center justify-center h-screen bg-gray-100">
      <div className="bg-white p-8 rounded shadow-lg text-center">
      <button><a href="https://maps.app.goo.gl/sDuutJzBMH8grFsC7"><img src="/map.png" alt="Google Logo" style={{ width: "24px", height: "24px", objectFit: "contain" }} />Near Hospital Location</a>
      
      </button>
        <h1 className="text-2xl font-bold mb-4"><b style={{ color: "white" }}>Login</b></h1>
        <input
          type="email"
          placeholder="Email address"
          className="w-full p-3 mb-4 bg-white rounded-xl shadow-inner text-gray-700 outline-none"
        />
<br/><br/>
        <input
          type="password"
          placeholder="Password"
          className="w-full p-3 mb-6 bg-white rounded-xl shadow-inner text-gray-700 outline-none"
        />
        <br/><br/>

        <button className="w-full p-3 text-white bg-purple-400 hover:bg-purple-500 rounded-xl shadow-lg">
          LOG-IN
        </button>
      <br/><br/>
        <button
          onClick={handleLogin}
          className="bg-blue-500 text-white p-3 rounded-lg flex items-center justify-center"
        >
         <img src="/glogo.png" alt="Google Logo" style={{ width: "24px", height: "24px", objectFit: "contain" }} />
    Sign in with Google
        </button>
      </div>
    </div>
  );
}
