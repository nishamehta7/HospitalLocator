import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyAdMh8qmTLucvDuyoklFWL4RwvwU-DTLEE",
  authDomain: "hospital-locator-e785d.firebaseapp.com",
  projectId: "hospital-locator-e785d",
  storageBucket: "hospital-locator-e785d.firebasestorage.app",
  messagingSenderId: "592594420412",
  appId: "1:592594420412:web:c38d10422e3e0bc2fe06b9",
  measurementId: "G-T688PBVJHP"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();

export { auth, provider };
