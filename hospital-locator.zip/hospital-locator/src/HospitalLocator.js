import React, { useState, useEffect } from "react";
import { GoogleMap, LoadScript, Marker } from "@react-google-maps/api";
import { signInWithPopup, signOut } from "firebase/auth";
import { auth, provider } from "./firebaseConfig"; // Your Firebase configuration
import "./styles.css"; // Your custom styles

export default function HospitalLocator() {
  const [user, setUser] = useState(null);
  const [location, setLocation] = useState(null); // Store user's location

  // Handle Google login
  const handleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, provider);
      setUser(result.user);
    } catch (error) {
      console.error("Login Failed", error);
    }
  };

  // Handle Google logout
  const handleLogout = () => {
    signOut(auth).then(() => setUser(null));
  };

  // Get user's geolocation
  useEffect(() => {
    if (user) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setLocation({ lat: latitude, lng: longitude }); // Update user's location
        },
        (error) => console.error("Location Access Denied", error)
      );
    }
  }, [user]);

  const containerStyle = {
    width: "100%",
    height: "500px",
  };

  return (
    <div className="p-4">
      {!user ? (
        <button onClick={handleLogin} className="bg-blue-500 text-white p-2 rounded">
          Login with Google
        </button>
      ) : (
        <>
          <div className="mb-2 flex justify-between items-center">
            <p>Welcome, {user.displayName}</p>
            <button onClick={handleLogout} className="bg-red-500 text-white p-2 rounded">
              Logout
            </button>
          </div>

          {/* Displaying User's Location */}
          {location && (
            <div className="mb-2">
              <p>Your current location is:</p>
              <p>Latitude: {location.lat}</p>
              <p>Longitude: {location.lng}</p>
            </div>
          )}

          {/* Google Map */}
          <LoadScript googleMapsApiKey={process.env.REACT_APP_GOOGLE_MAPS_API_KEY}>
            <GoogleMap
              mapContainerStyle={containerStyle}
              center={location || { lat: 0, lng: 0 }} // Default to 0,0 if location is not available
              zoom={14}
            >
              {/* Mark user's location */}
              {location && <Marker position={location} />}
            </GoogleMap>
          </LoadScript>
        </>
      )}
    </div>
  );
}
